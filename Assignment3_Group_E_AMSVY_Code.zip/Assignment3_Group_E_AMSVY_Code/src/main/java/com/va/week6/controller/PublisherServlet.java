package com.va.week6.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.va.week6.dao.PublisherDao;
import com.va.week6.model.Publisher;

/**
 * Servlet implementation class PublisherServlet
 */
@WebServlet("/PublisherServlet")
public class PublisherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PublisherDao publisherdao;

	public void init() {
		publisherdao = new PublisherDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String method = request.getParameter("method");
		String name = request.getParameter("name");
		String address = request.getParameter("address");

		// insert the data
		if (method.equals("insert")) {
			Publisher st = new Publisher();

			st.setName(name);
			st.setAddress(address);

			try {
				publisherdao.addPublisher(st);
			} catch (Exception e) {
				e.printStackTrace();
			}
			response.sendRedirect("Success.jsp");// response goes to view!!
		}

		// update the data
		else if (method.equals("update")) {

			Publisher st1 = new Publisher();

			st1.setPublisherID(request.getParameter("publisherid"));
			st1.setName(request.getParameter("name"));
			st1.setAddress(request.getParameter("address"));
			try {
				publisherdao.updatePublisher(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

		// delete the data
		else if (method.equals("delete")) {

			Publisher st1 = new Publisher();

			st1.setPublisherID(request.getParameter("publisherid"));

			try {
				publisherdao.deletePublisher(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

	}

}
