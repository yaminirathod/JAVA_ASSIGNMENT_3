package com.va.week6.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ThreadLocalRandom;

import com.va.week6.model.Book;

public class BookDao {

	public int addBook(Book st) {
		String INSERT_USERS_SQL = "INSERT INTO book" + " VALUES " + "(?,?,?,?,?,?);";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setInt(1, ThreadLocalRandom.current().nextInt());
			ps.setString(2, st.getAuthor());
			ps.setString(3, st.getTitle());
			ps.setString(4, st.getPrice());
			ps.setString(5, st.getAvailable());
			ps.setString(6, st.getPublisherid());

			System.out.println(ps);

			result = ps.executeUpdate();

		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;
	}
	/*
	 * Exception -function for printing SQL State, Error Code and Message ..
	 */

	public int updateBook(Book st) {
		String INSERT_USERS_SQL = "UPDATE book SET author=?, title=?, price=?, available=?, publisherid=?"
				+ " WHERE bookid=?";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setString(1, st.getAuthor());
			ps.setString(2, st.getTitle());
			ps.setString(3, st.getPrice());
			ps.setString(4, st.getAvailable());
			ps.setString(5, st.getPublisherid());
			ps.setString(6, st.getBookID());

			System.out.println(ps);
			result = ps.executeUpdate();
		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;

	}

	public int deleteBook(Book st) {
		String INSERT_USERS_SQL = "DELETE FROM book" + " WHERE bookid=?";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setString(1, st.getBookID());

			System.out.println(ps);
			result = ps.executeUpdate();
		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;

	}

	public int issueBook(Book st) {
		String INSERT_USERS_SQL = "INSERT INTO issuebook" + " VALUES " + "(?,?,?,?,?,?,?,?);";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setString(1, st.getBookID());
			ps.setString(2, st.getAuthor());
			ps.setString(3, st.getTitle());
			ps.setString(4, st.getPrice());
			ps.setString(5, st.getAvailable());
			ps.setString(6, st.getMembid());
			ps.setString(7, st.getIssuedate());
			ps.setString(8, st.getReturndate());
			

			System.out.println(ps);

			result = ps.executeUpdate();

		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;

	}

	private void printSQLException(SQLException ex) {

		for (Throwable e : ex) {
			if (e instanceof SQLException) {

				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + ((SQLException) e).getMessage());

				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause" + t);
					t = t.getCause();
				}
			}

		}
	}

}
