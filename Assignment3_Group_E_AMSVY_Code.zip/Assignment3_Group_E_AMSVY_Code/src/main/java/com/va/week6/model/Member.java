package com.va.week6.model;

public class Member {
	private String membid;
	private String name; 
	private String address;
	private String membtype;
	private String membdate;
	private String expdate;
	
	public String getExpdate() {
		return expdate;
	}

	public void setExpdate(String expdate) {
		this.expdate = expdate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMembtype() {
		return membtype;
	}
	public void setMembtype(String membtype) {
		this.membtype = membtype;
	}
	public String getMembdate() {
		return membdate;
	}
	public void setMembdate(String membdate) {
		this.membdate = membdate;
	}
	public void setID(String membid) {
		this.membid = membid;
		
	}
	public String getMembID() {
		return membid;
	}
}
