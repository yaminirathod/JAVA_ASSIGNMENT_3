package com.va.week6.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.va.week6.dao.BookDao;
import com.va.week6.model.Book;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BookDao bookdao;

	public void init() {
		bookdao = new BookDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String method = request.getParameter("method");
		String bookid = request.getParameter("bookid");
		String author = request.getParameter("author");
		String title = request.getParameter("title");
		String price = request.getParameter("price");
		String issuedate = request.getParameter("issuedate");
		String returndate = request.getParameter("returndate");
		String available = request.getParameter("available");
		String membid = request.getParameter("membid");
		String publisherid = request.getParameter("publisherid");

		// insert the data
		if (method.equals("insert")) {
			Book st = new Book();

			st.setAuthor(author);
			st.setTitle(title);
			st.setPrice(price);
			st.setAvailable(available);
			st.setPublisherid(publisherid);

			try {
				bookdao.addBook(st);
			} catch (Exception e) {
				e.printStackTrace();
			}
			response.sendRedirect("Success.jsp");// response goes to view!!
		}

		// update the data
		else if (method.equals("update")) {

			Book st1 = new Book();

			st1.setBookID(request.getParameter("bookid"));
			st1.setAuthor(request.getParameter("author"));
			st1.setTitle(request.getParameter("title"));
			st1.setPrice(request.getParameter("price"));
			st1.setAvailable(request.getParameter("available"));
			st1.setPublisherid(request.getParameter("publisherid"));
			try {
				bookdao.updateBook(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

		// delete the data
		else if (method.equals("delete")) {

			Book st1 = new Book();

			st1.setBookID(request.getParameter("bookid"));

			try {
				bookdao.deleteBook(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

		// issue the book
		else if (method.equals("issue")) {

			Book st = new Book();

			st.setBookID(bookid);
			st.setAuthor(author);
			st.setTitle(title);
			st.setPrice(price);
			st.setAvailable(available);
			st.setIssuedate(issuedate);
			st.setReturndate(returndate);
			st.setMembid(membid);

			if(available.equals("Yes") || available.equals("yes"))
			{
				try {
					bookdao.issueBook(st);
				} catch (Exception e) {
					e.printStackTrace();
				}
				response.sendRedirect("Success.jsp");// response goes to view!!
			}
			else
			{
				response.sendRedirect("Unavailable.jsp");
			}
			
		}

	}

}
