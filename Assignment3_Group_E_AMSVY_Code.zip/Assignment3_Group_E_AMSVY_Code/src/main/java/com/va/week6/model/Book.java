package com.va.week6.model;

public class Book {
	private String bookid;
	private String author;
	private String title;
	private String price;
	private String available;
	private String issuedate;
	private String returndate;
	private String membid;
	private String publisherid;

	public String getMembid() {
		return membid;
	}

	public String getPublisherid() {
		return publisherid;
	}

	public void setPublisherid(String publisherid) {
		this.publisherid = publisherid;
	}

	public void setMembid(String membid) {
		this.membid = membid;
	}

	public String getIssuedate() {
		return issuedate;
	}

	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}

	public String getReturndate() {
		return returndate;
	}

	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
	}

	public void setBookID(String bookid) {
		this.bookid = bookid;

	}

	public String getBookID() {
		return bookid;
	}

}
