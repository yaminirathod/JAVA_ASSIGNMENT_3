package com.va.week6.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.va.week6.dao.MemberDao;
import com.va.week6.model.Member;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/MemberServlet")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MemberDao membdao;

	public void init() {
		membdao = new MemberDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String method = request.getParameter("method");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String membtype = request.getParameter("membtype");
		String membdate = request.getParameter("membdate");
		String expdate = request.getParameter("expdate");

		// insert the data
		if (method.equals("insert")) {
			Member st = new Member();

			st.setName(name);
			st.setAddress(address);
			st.setMembtype(membtype);
			st.setMembdate(membdate);
			st.setExpdate(expdate);

			try {
				membdao.addMember(st);
			} catch (Exception e) {
				e.printStackTrace();
			}
			response.sendRedirect("Success.jsp");// response goes to view!!
		}

		// update the data
		else if (method.equals("update")) {

			Member st1 = new Member();

			st1.setID(request.getParameter("membid"));
			st1.setName(request.getParameter("name"));
			st1.setAddress(request.getParameter("address"));
			st1.setMembtype(request.getParameter("membtype"));
			st1.setMembdate(request.getParameter("membdate"));
			st1.setExpdate(request.getParameter("expdate"));
			try {
				membdao.updateMember(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

		// delete the data
		else if (method.equals("delete")) {

			Member st1 = new Member();

			st1.setID(request.getParameter("membid"));

			try {
				membdao.deleteMember(st1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Record updated Successfully");
			response.sendRedirect("Success.jsp");
		}

	}

}
