package com.va.week6.model;

public class Publisher {
	private String publisherid;
	private String name;
	private String address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPublisherID() {
		return publisherid;
	}

	public void setPublisherID(String publisherid) {
		this.publisherid = publisherid;
	}

}
