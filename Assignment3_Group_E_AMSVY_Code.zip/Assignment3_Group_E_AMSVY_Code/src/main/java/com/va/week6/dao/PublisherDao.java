package com.va.week6.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ThreadLocalRandom;

import com.va.week6.model.Publisher;

public class PublisherDao {

	public int addPublisher(Publisher st) {
		String INSERT_USERS_SQL = "INSERT INTO publisher" + " VALUES " + "(?,?,?);";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setInt(1, ThreadLocalRandom.current().nextInt());
			ps.setString(2, st.getName());
			ps.setString(3, st.getAddress());

			System.out.println(ps);

			result = ps.executeUpdate();

		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;
	}
	/*
	 * Exception -function for printing SQL State, Error Code and Message ..
	 */

	public int updatePublisher(Publisher st) {
		String INSERT_USERS_SQL = "UPDATE publisher SET name=?, address=?" + " WHERE publisherid=?";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setString(1, st.getName());
			ps.setString(2, st.getAddress());
			ps.setString(3, st.getPublisherID());

			System.out.println(ps);

			result = ps.executeUpdate();

		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;

	}

	private void printSQLException(SQLException ex) {

		for (Throwable e : ex) {
			if (e instanceof SQLException) {

				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + ((SQLException) e).getMessage());

				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause" + t);
					t = t.getCause();
				}
			}

		}
	}

	public int deletePublisher(Publisher st) {
		String INSERT_USERS_SQL = "DELETE FROM publisher" + " WHERE publisherid=?";

		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing", "root", "root");
				PreparedStatement ps = connection.prepareStatement(INSERT_USERS_SQL)) {

			ps.setString(1, st.getPublisherID());

			System.out.println(ps);
			result = ps.executeUpdate();
		}

		catch (SQLException e) {
			printSQLException(e); // calling printSQLException function...
		}
		return result;

	}

}
